(function(window, undefined) {

  var jimLinks = {
    "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac" : {
      "Image_7" : [
        "94c1971d-806c-4fe9-9007-4eca685fa4c8"
      ]
    },
    "94c1971d-806c-4fe9-9007-4eca685fa4c8" : {
      "Cell_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_119" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Cell_5" : [
        "c97f0615-b604-4e5d-bb8b-9a4aeaa4f8e8"
      ],
      "Image_72" : [
        "c97f0615-b604-4e5d-bb8b-9a4aeaa4f8e8"
      ],
      "Cell_6" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "Image_3" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "Cell_1" : [
        "099c4643-a8e6-4e98-a3eb-3b834450e537"
      ],
      "Image_34" : [
        "099c4643-a8e6-4e98-a3eb-3b834450e537"
      ],
      "Two-line-item_5" : [
        "efddaa97-b46b-4cfc-8355-651eb0cb4ff9"
      ],
      "Circle" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "Image_71" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ]
    },
    "c97f0615-b604-4e5d-bb8b-9a4aeaa4f8e8" : {
      "Rectangle_2" : [
        "ad3e29a3-a64c-41f6-9ba4-716b9b715bab"
      ],
      "Circle" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "Image_76" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "Rectangle_3" : [
        "ad3e29a3-a64c-41f6-9ba4-716b9b715bab"
      ],
      "Cell_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Cell_2" : [
        "c97f0615-b604-4e5d-bb8b-9a4aeaa4f8e8"
      ],
      "Image_71" : [
        "94c1971d-806c-4fe9-9007-4eca685fa4c8"
      ]
    },
    "8f44f3f5-aa7d-4ce3-a191-228673510740" : {
      "Circle" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "Image_76" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "flat_Button_lightTheme_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_71" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "flat_Button_lightTheme_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Category_1" : [
        "ab3bdd2e-97df-497a-ab12-46a3b7819bee"
      ]
    },
    "099c4643-a8e6-4e98-a3eb-3b834450e537" : {
      "Image_71" : [
        "94c1971d-806c-4fe9-9007-4eca685fa4c8"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_2" : [
        "8f44f3f5-aa7d-4ce3-a191-228673510740"
      ],
      "Circle" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "Ellipse_23" : [
        "00e2e598-495a-4e7d-8b14-7d90e67307db"
      ],
      "plus_2" : [
        "8f44f3f5-aa7d-4ce3-a191-228673510740"
      ],
      "Image_76" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "Rectangle_3" : [
        "8f44f3f5-aa7d-4ce3-a191-228673510740"
      ],
      "Rectangle_7" : [
        "8f44f3f5-aa7d-4ce3-a191-228673510740"
      ],
      "Cell_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Cell_7" : [
        "c97f0615-b604-4e5d-bb8b-9a4aeaa4f8e8"
      ],
      "Rectangle_4" : [
        "8f44f3f5-aa7d-4ce3-a191-228673510740"
      ],
      "Image_71" : [
        "94c1971d-806c-4fe9-9007-4eca685fa4c8"
      ]
    },
    "00e2e598-495a-4e7d-8b14-7d90e67307db" : {
      "Circle" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "Image_76" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "flat_Button_lightTheme_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_71" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "flat_Button_lightTheme_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "bade00e7-648b-474d-959b-2df48c8ae997" : {
    },
    "efddaa97-b46b-4cfc-8355-651eb0cb4ff9" : {
      "Circle_1" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "arrow-back_5" : [
        "94c1971d-806c-4fe9-9007-4eca685fa4c8"
      ]
    },
    "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36" : {
      "Circle" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "Image_76" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "Image_71" : [
        "94c1971d-806c-4fe9-9007-4eca685fa4c8"
      ]
    },
    "ad3e29a3-a64c-41f6-9ba4-716b9b715bab" : {
      "Circle" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "Image_76" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "Image_71" : [
        "c97f0615-b604-4e5d-bb8b-9a4aeaa4f8e8"
      ],
      "Image_46" : [
        "00e2e598-495a-4e7d-8b14-7d90e67307db"
      ]
    },
    "ab3bdd2e-97df-497a-ab12-46a3b7819bee" : {
      "Circle" : [
        "648d75ec-76cf-4f7c-9fc3-9e72b088a1ac"
      ],
      "Image_76" : [
        "b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36"
      ],
      "Image_71" : [
        "8f44f3f5-aa7d-4ce3-a191-228673510740"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);