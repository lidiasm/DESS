(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimUtil, {
        "loadScrollBars": function() {
            jQuery(".s-648d75ec-76cf-4f7c-9fc3-9e72b088a1ac .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-94c1971d-806c-4fe9-9007-4eca685fa4c8 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-94c1971d-806c-4fe9-9007-4eca685fa4c8 #s-Content .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-c97f0615-b604-4e5d-bb8b-9a4aeaa4f8e8 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-c97f0615-b604-4e5d-bb8b-9a4aeaa4f8e8 #s-Items .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-8f44f3f5-aa7d-4ce3-a191-228673510740 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-8f44f3f5-aa7d-4ce3-a191-228673510740 #s-Items .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-8f44f3f5-aa7d-4ce3-a191-228673510740 #s-Category_2 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-8f44f3f5-aa7d-4ce3-a191-228673510740 #s-Category_1 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-099c4643-a8e6-4e98-a3eb-3b834450e537 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-099c4643-a8e6-4e98-a3eb-3b834450e537 #s-Content .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Items .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-00e2e598-495a-4e7d-8b14-7d90e67307db .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-00e2e598-495a-4e7d-8b14-7d90e67307db #s-Items .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-00e2e598-495a-4e7d-8b14-7d90e67307db #s-Category_1 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-00e2e598-495a-4e7d-8b14-7d90e67307db #s-Category_2 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-bade00e7-648b-474d-959b-2df48c8ae997 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-efddaa97-b46b-4cfc-8355-651eb0cb4ff9 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36 .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-b7bd4656-d0c7-4ebb-989e-7aeb31dd5a36 #s-Content .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-ad3e29a3-a64c-41f6-9ba4-716b9b715bab .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-ad3e29a3-a64c-41f6-9ba4-716b9b715bab #s-Items .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-ab3bdd2e-97df-497a-ab12-46a3b7819bee .ui-page").overscroll({ showThumbs:true, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-ab3bdd2e-97df-497a-ab12-46a3b7819bee #s-Items .layoutWrapper").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
            jQuery(".s-ab3bdd2e-97df-497a-ab12-46a3b7819bee #s-Category_1 .scroll").overscroll({ showThumbs:false, direction:'vertical', roundCorners:false, backgroundColor:'#333333', opacity:'0.7', thickness:'4'});
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);